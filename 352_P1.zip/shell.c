#include <stdio.h>
#include <unistd.h>
#define MAXLINE 80 /* The maximum length command */
int shouldrun = 1; /* flag to determine when to exit program */

int main(void){
    char *args[MAXLINE/2 + 1]; /* command line arguments */
    int ps;
    char input[MAXLINE];
    while (shouldrun) {
        printf("osh>");
        fflush(stdout);
        scanf("%s", input);

        /**
        After reading user input, the steps are:
        (1) fork a child process using fork()
        (2) the child process will invoke execvp()
        (3) if command included &, parent will invoke wait()
        */

        // (1)
        ps = fork();
        if(ps ==0){
            //child process
            //parse input
            int length = strlen(input);
            int curArg = 0;
            for(int i=0; i<length; i++){
                if(input[i] != ' '){
                    //append to current arguement
                    args[curArg] = input[i];
                }
                else{
                    //start new arg
                    curArg++;
                }
            }

            //check if & is used for running in the background
            execvp(args[0], args);
        }
        else if(ps > 1){
            //parent process

        }
        else{
            //error
            printf("Error creating child process");
        }
    }
    return 0;
}

void execvp(char *command, char *params[]){
    /* exit command */
    if(strcmp(command, 'exit') == 0 || strcmp(command, 'Exit') == 0){
        shouldrun = 0;
        return;
    }

    /* history command */
    else if(strcmp(command, '!!') == 0){
        

        return;
    }
    else if(strcmp(command, '!?') == 0){
        //how to check for nums 1-10?

        return;
    }
    /* multiple commands */

    /* pipe(|)..MORE command */

    /* cd command */
    else if(strcmp(command, 'cd') == 0){
        //adjust recent commands list

        //iterate through options and find the appropriate command
        char next;
        int length = strlen(argv[1]);
        for(int i=0; i<length; i++){
            next = argv[1][i];
            
        }
        return;
    }
}